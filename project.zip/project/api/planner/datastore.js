exports.planner = [
{id: 'a4vhAoFG', location: "Joe Bloggs", attraction: "1 Bank Lane", approx_cost: "051-123456 "},
 {id: 'hwX6aOr7', location: "Ellen Bliggs", attraction: "2 River Road", approx_cost: "051-123457"}
]